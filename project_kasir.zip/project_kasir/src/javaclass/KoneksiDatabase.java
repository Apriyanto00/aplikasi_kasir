package javaclass;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class KoneksiDatabase {
    private static Connection koneksi;

    public static Connection getConnection() throws SQLException {
        try {
            if (koneksi == null || koneksi.isClosed()) {
                String url = "jdbc:mysql://localhost:3306/kasir?serverTimezone=UTC";
                String user = "root";
                String password = ""; // kosongkan jika root tidak pakai password
                koneksi = DriverManager.getConnection(url, user, password);
            }
        } catch (SQLException e) {
            throw new SQLException("Gagal koneksi ke database: " + e.getMessage());
        }
        return koneksi;
    }
}
